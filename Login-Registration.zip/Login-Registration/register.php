<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 

@include('config.php');

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $user_type = $_POST['user_type'];

    // Check if the email already exists
    $select = "SELECT * FROM user WHERE email = ?";
    $stmt = mysqli_prepare($mysqli, $select);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $error[] = 'User Already Exists!';
    } else {
        if ($password != $cpassword) {
            $error[] = 'Password not matched!';
        } else {
            // Password policy checks
            $password_strength = getPasswordStrength($password);

            if ($password_strength < 3) {
                $error[] = 'Password is weak. Please use a stronger password.';
            } else {
                // CAPTCHA verification
                $captcha_response = $_POST['g-recaptcha-response'];
                $secret_key = '6LfVokEpAAAAABGhp53v7HdfqIjbWDYMm8jNXuu5';
                $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secret_key&response=$captcha_response";
                $recaptcha_response = file_get_contents($url);
                $recaptcha_data = json_decode($recaptcha_response);

                if (!$recaptcha_data->success) {
                    $error[] = 'CAPTCHA verification failed. Please confirm you are not a robot.';
                } else {
                    // Hash the password securely
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    // Insert user data into the database
                    $insert = "INSERT INTO user(Name, Email, Password, User_type) VALUES (?, ?, ?, ?)";
                    $stmt = mysqli_prepare($mysqli, $insert);
                    mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hashed_password, $user_type);
                    mysqli_stmt_execute($stmt);

                    // Redirect to a login after successful registration
                    header('location: login.php');
                    exit();
                }
            }
        }
    }
}

function getPasswordStrength($password) {
    $strength = 0;

    // Check length
    $length = strlen($password);
    if ($length >= 8) {
        $strength += 1;
    }

    // Check for uppercase letters
    if (preg_match('/[A-Z]/', $password)) {
        $strength += 1;
    }

    // Check for lowercase letters
    if (preg_match('/[a-z]/', $password)) {
        $strength += 1;
    }

    // Check for numbers
    if (preg_match('/[0-9]/', $password)) {
        $strength += 1;
    }

    // Check for special characters
    if (preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $strength += 1;
    }

    return $strength;
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>

    <!-- custom css file link-->
    <link rel="stylesheet" type="text/css" href="register-style.css?v=1.1">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>

<div class="container">
    <div class="your-wrapper-div"> 

        <form action="" method="post">

             <h3>Register Now</h3>

             <?php 
               if (isset($error)) {
                   foreach ($error as $error) {
                       echo '<span class="error-msg">' . $error . '</span>';
                   }
               }
             ?>

             <div class="form-group">
                 <input type="text" name="name" required placeholder="Enter your full name">
             </div>

             <div class="form-group">
                 <input type="email" name="email" required placeholder="Enter email">
             </div>

             <div class="form-group">
                 <input type="password" name="password" id="password" required placeholder="Enter password" oninput="checkPasswordStrength()">
                 
             </div>

             <div id="lengthMsg"></div>
             <div id="uppercaseMsg"></div>
             <div id="lowercaseMsg"></div>
             <div id="numberMsg"></div>
             <div id="specialCharMsg"></div>

             <div class="form-group">
                 <input type="password" name="cpassword" required placeholder="Confirm password">
             </div>

             <select name="user_type">
                <option value="User">User</option>
                <option value="Admin">Admin</option>
             </select>
            
             <div class="form-group">
                <div class="g-recaptcha" data-sitekey="6LfVokEpAAAAAACBe1Ld0vJ1yg5yDVgag1JFvYYj"></div>
             </div>

             <div class="form-group">
                    <input type="submit" name="submit" value="Register" class="form-btn">
             </div>

             <p> Already have an account? <a href="/Login-Registration/login.php">Login</a></p>

        </form>
    </div> 
</div>

<script>
    function checkPasswordStrength() {
        var password = document.getElementById('password').value;
        var lengthCheck = password.length >= 8;
        var uppercaseCheck = /[A-Z]/.test(password);
        var lowercaseCheck = /[a-z]/.test(password);
        var numberCheck = /[0-9]/.test(password);
        var specialCharCheck = /[!@#$%^&*(),.?":{}|<>]/.test(password);

        document.getElementById('lengthMsg').innerHTML = lengthCheck ? '✓ Length' : '✗ Length (min 8 characters)';
        document.getElementById('uppercaseMsg').innerHTML = uppercaseCheck ? '✓ Uppercase' : '✗ Uppercase';
        document.getElementById('lowercaseMsg').innerHTML = lowercaseCheck ? '✓ Lowercase' : '✗ Lowercase';
        document.getElementById('numberMsg').innerHTML = numberCheck ? '✓ Number' : '✗ Number';
        document.getElementById('specialCharMsg').innerHTML = specialCharCheck ? '✓ Special Character' : '✗ Special Character';

        // Set text color to white 
        document.getElementById('lengthMsg').style.color = 'white';
        document.getElementById('uppercaseMsg').style.color = 'white';
        document.getElementById('lowercaseMsg').style.color = 'white';
        document.getElementById('numberMsg').style.color = 'white';
        document.getElementById('specialCharMsg').style.color = 'white';
    }

    $(document).on('click', '#submit', function() {
        var response = grecaptcha.getResponse();
        if (response.length === 0) {
        alert("Please verify you are not a robot");
        return false;
    }
});

</script>
</body>
</html>
