<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('config.php'); 

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember_me = isset($_POST['remember_me']) ? true : false;

    // CAPTCHA verification
    $captcha_response = $_POST['g-recaptcha-response'];
    $secret_key = '6LfVokEpAAAAABGhp53v7HdfqIjbWDYMm8jNXuu5';
    $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secret_key&response=$captcha_response";
    $recaptcha_response = file_get_contents($url);
    $recaptcha_data = json_decode($recaptcha_response);

    if (!$recaptcha_data->success) {
        $error[] = 'CAPTCHA verification failed. Please confirm you are not a robot.';
    } else {
        $select = "SELECT * FROM user WHERE email = ?";
        $stmt = mysqli_prepare($mysqli, $select);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($row = mysqli_fetch_assoc($result)) {
                $hashed_password = $row['Password'];

                if (password_verify($password, $hashed_password)) {
                    // Password is correct, start a session
                    session_start();

                    $_SESSION['user_id'] = $row['ID'];
                    $_SESSION['user_type'] = $row['User_type'];

                    // Redirect based on user type
                    if ($row['User_type'] == 'Admin') {
                        header('location: admin_page.php');
                    } else {
                        header('location: user_page.php');
                    }

                    exit();
                } else {
                    $error[] = 'Invalid password';
                }
            } else {
                $error[] = 'User not found';
            }
        } else {
            $error[] = 'Error in preparing the statement';
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>

    <!-- custom css file link-->
    <link rel="stylesheet" type="text/css" href="login-style.css?v=1.1">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>

<div class="container">
    <div class="your-wrapper-div"> 

        <form action="" method="post">

             <h1>Log In</h1>

             <style>
                .error-msg {
                color: white;
                }
             </style>

             <?php 
               if (isset($error)) {
                   foreach ($error as $error) {
                       echo '<span class="error-msg">' . $error . '</span>';
                   }
               }
             ?>

             <div class="form-group">
                 <input type="email" name="email" class="inputField" required placeholder="Enter email">
             </div>

             <div class="form-group">
                 <input type="password" name="password" class="inputField" required placeholder="Enter password">
             </div>

             <div class="form-group">
                 <input type="checkbox" name="remember_me"><label class="remember-forget">Remember Me</label>
                 <p class="forgotPassword"><a href="/Login-Registration/forgot-password.php">Forgot Password?</a></p>

             </div>

             <div class="form-group">
                <div class="g-recaptcha" data-sitekey="6LfVokEpAAAAAACBe1Ld0vJ1yg5yDVgag1JFvYYj"></div>
             </div>

             <div class="form-group">
                    <input type="submit" name="login" value="Login" class="form-btn">
             </div>

             <p class="register-link" >Don't have an account? <a href="/Login-Registration/register.php">Register now</a></p>
             
        </form>
    </div> 
</div>

</body>
</html>
