# UserLogin with Strong Security Policy

# Security Policy consists of Google reCaptcha, password strenghth, proper data inputs, strong passwords that gets hashed and is seen in encrypted format which reduces risks

# As for now to install and run this prototype, you can download zip file, extract it and try running it with localhost on your desired browser





